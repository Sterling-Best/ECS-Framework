#include "entity_component_systems_framework.h"


namespace ECSF {

	void Initialize() {
		_entityComponentSystemFramekwork = EntityComponentSystemsFramework();
	}

	template<typename ComponentType>
		void AccomponentType() {
			_entityComponentSystemFramekwork.GetComponentFramework().GetManagerRegistery().GetManagerRepository().
	}

	template<typename ComponentType>
	void ChangeComponent() {
		auto getto = _entityComponentSystemFramekwork.GetComponentFramework().GetManagerRegistery().GetManagerRepository().GetComponentManager<ComponentType>().GetRepository();
	}




	

	namespace {
		EntityComponentSystemsFramework _entityComponentSystemFramekwork;

	}

}