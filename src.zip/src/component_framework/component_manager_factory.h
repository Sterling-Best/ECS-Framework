class ComponentManagerFactory {

};