#include "component_framework/component_framework.h"

class EntityComponentSystemsFramework {

public:

	

private:

	ComponentFramework _componentFramework = ComponentFramework();

	//TODO: Create a ID manager and Geenrator

};